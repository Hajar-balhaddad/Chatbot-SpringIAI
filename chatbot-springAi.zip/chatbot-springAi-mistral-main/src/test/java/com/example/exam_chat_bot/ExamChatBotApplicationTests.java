package com.example.exam_chat_bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamChatBotApplicationTests {

    @Test
    void contextLoads() {
    }

}
