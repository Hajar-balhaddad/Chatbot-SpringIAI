 Answer the provided question using only the given context.
 If you do not have the answer, answer only with : aucun reponse
 CONTEXT:
 {context}
 QUESTION:
 {question}