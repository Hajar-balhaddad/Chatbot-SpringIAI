enum Matcher {
    EQUALS = "EQUALS",
    CONTAINS = "CONTAINS",
    LESS_THAN = "LESS_THAN",
    GREATER_THAN = "GREATER_THAN"
}
export default Matcher;
