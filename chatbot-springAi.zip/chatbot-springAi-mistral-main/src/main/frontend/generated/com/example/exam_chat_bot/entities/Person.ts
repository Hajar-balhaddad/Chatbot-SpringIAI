interface Person {
    id?: number;
    name?: string;
    email?: string;
}
export default Person;
