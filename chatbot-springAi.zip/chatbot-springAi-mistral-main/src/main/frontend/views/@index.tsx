import "../styles/styles.css"
import "bootstrap/dist/css/bootstrap.min.css"

export default function Index(){
    return (
        <div className="p-m">
            <h1> page test </h1>
        </div>
    )
}