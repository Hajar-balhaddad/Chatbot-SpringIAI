@NonNullApi
package com.example.exam_chat_bot.services;

import org.springframework.lang.NonNullApi;