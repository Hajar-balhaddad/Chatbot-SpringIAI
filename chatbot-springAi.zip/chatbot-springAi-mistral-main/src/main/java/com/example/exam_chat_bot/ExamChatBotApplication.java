package com.example.exam_chat_bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamChatBotApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamChatBotApplication.class, args);
    }

}
